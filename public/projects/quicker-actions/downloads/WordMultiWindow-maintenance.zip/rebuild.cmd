@echo off
setlocal
powershell.exe -NoProfile -Command "$quickerProjectRoot = '%~dp0'; Invoke-Expression ([IO.File]::ReadAllText((Join-Path $quickerProjectRoot 'tools\build-action.ps1')))"
if errorlevel 1 (
 echo Build failed. Existing imported action was not changed.
 pause
 exit /b 1
)
echo Build complete. Import the JSON from the action folder to test it.
pause