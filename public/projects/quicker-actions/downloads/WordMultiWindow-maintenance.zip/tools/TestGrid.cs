using System;
using System.Drawing;
class TestGrid {
 static void Main(){
  foreach(var area in new[]{new Rectangle(0,0,1920,1040),new Rectangle(-2560,0,2560,1400),new Rectangle(0,-1080,1537,1001)})
   for(int n=1;n<=24;n++){
    var cells=Program.Grid(area,n);long total=0;
    if(cells.Length!=n)throw new Exception("Count");
    for(int i=0;i<n;i++){var c=cells[i];if(c.Width<=0||c.Height<=0||!area.Contains(c))throw new Exception("Bounds");total+=(long)c.Width*c.Height;for(int j=0;j<i;j++)if(c.IntersectsWith(cells[j]))throw new Exception("Overlap");}
    if(total!=(long)area.Width*area.Height)throw new Exception("Coverage");
    if(n==2&&(cells[0].Height!=area.Height||cells[1].Height!=area.Height))throw new Exception("Side by side");
   }
  Console.WriteLine("PASS: 72 grid cases; no overlap, full coverage, negative coordinates and odd dimensions.");
 }
}
