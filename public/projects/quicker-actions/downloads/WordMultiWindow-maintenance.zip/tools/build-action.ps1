﻿$ErrorActionPreference='Stop'
if (-not $quickerProjectRoot) { $quickerProjectRoot=Split-Path -Parent $PSScriptRoot }
$quickerProjectRoot=[IO.Path]::GetFullPath($quickerProjectRoot)
$sourcePath=Join-Path $quickerProjectRoot 'action\WordMultiWindow.cs'
$dest=Join-Path $quickerProjectRoot 'action\Word同文多窗.json'
$csc=Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$buildDir=Join-Path $quickerProjectRoot '.build'
New-Item -ItemType Directory -Path $buildDir -Force | Out-Null
$compiled=Join-Path $buildDir 'WordMultiWindow.dll'
$testExe=Join-Path $buildDir 'TestGrid.exe'
try {
 & $csc /nologo /target:library "/out:$compiled" /r:System.Windows.Forms.dll /r:System.Drawing.dll /r:Microsoft.CSharp.dll $sourcePath
 if($LASTEXITCODE -ne 0){throw 'C# compilation failed'}
 & $csc /nologo "/out:$testExe" "/r:$compiled" /r:System.Drawing.dll (Join-Path $quickerProjectRoot 'tools\TestGrid.cs')
 if($LASTEXITCODE -ne 0){throw 'Test compilation failed'}
 & $testExe
 if($LASTEXITCODE -ne 0){throw 'Grid tests failed'}
} finally {
 foreach($temporary in @($compiled,$testExe)){if(Test-Path -LiteralPath $temporary){Remove-Item -LiteralPath $temporary}}
 if((Get-ChildItem -LiteralPath $buildDir -Force | Measure-Object).Count -eq 0){Remove-Item -LiteralPath $buildDir}
}
[AppDomain]::CurrentDomain.add_AssemblyResolve({param($sender,$args) $p=Join-Path 'C:\Program Files\Quicker' (($args.Name.Split(',')[0])+'.dll');if(Test-Path -LiteralPath $p){[Reflection.Assembly]::LoadFrom($p)}})
foreach($lib in @('Newtonsoft.Json.dll','Quicker.Common.dll','Quicker.exe')){[void][Reflection.Assembly]::LoadFrom(('C:\Program Files\Quicker\'+$lib))}
$code=[IO.File]::ReadAllText($sourcePath)
$definition=@{
 LimitSingleInstance=$true; SummaryExpression=''; SubPrograms=@(); Variables=@()
 Steps=@(
  @{StepRunnerKey='sys:restoreActiveWindow';InputParams=@{};OutputParams=@{};Note='返回调出面板前的 Word 窗口'},
  @{StepRunnerKey='sys:csscript';InputParams=@{
    mode=@{Value='low_permission_roslyn'};scriptForLp=@{Value=$code};
    paramValue=@{VarKey='quicker_in_param'};reference=@{Value="System.Windows.Forms.dll`nSystem.Drawing.dll`nMicrosoft.CSharp.dll"};
    waitResp=@{Value='1'};waitMs=@{Value='300000'};stopIfFail=@{Value='1'};enableCache=@{Value='1'}
   };OutputParams=@{};Note='原生 Word 同文档窗口：双窗、自定义数量、独立滚动与排列'}
 )
}
$xjson=ConvertTo-Json -InputObject $definition -Depth 20
$typed=[Newtonsoft.Json.JsonConvert]::DeserializeObject($xjson,[Quicker.Domain.Actions.X.XAction])
if($typed.Steps.Count -ne 2){throw 'Step schema validation failed'}
$item=New-Object Quicker.Common.ActionItem
if(Test-Path -LiteralPath $dest){$item.Id=([IO.File]::ReadAllText($dest) | ConvertFrom-Json).Id}else{$item.Id=[Guid]::NewGuid().ToString()};$item.ActionType=[Quicker.Common.ActionType]::XAction
$item.Title='Word 同文多窗';$item.Description='左键补齐双窗并排列；右键自定义窗口总数。同一文档，内容同步、滚动独立。'
$item.Icon='fa:Solid_Columns:#185ABD';$item.Data=$xjson;$item.ContextMenuData='自定义窗口总数…|custom';$item.MinQuickerVersion='1.45.5';$item.DoNotClosePanel=$false
$json=[Newtonsoft.Json.JsonConvert]::SerializeObject($item,[Newtonsoft.Json.Formatting]::Indented)

[IO.File]::WriteAllText($dest,$json,(New-Object Text.UTF8Encoding($false)))
$roundTrip=[Newtonsoft.Json.JsonConvert]::DeserializeObject([IO.File]::ReadAllText($dest),[Quicker.Common.ActionItem])
if($roundTrip.ActionType -ne [Quicker.Common.ActionType]::XAction -or $roundTrip.ContextMenuData -ne $item.ContextMenuData){throw 'Action schema validation failed'}
'Action JSON validated against installed Quicker 1.45.5 types.'
